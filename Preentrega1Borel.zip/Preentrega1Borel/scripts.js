
function seleccionTipo(){

 
   let tipo= prompt("ingrese la opcion que desea entrenar, o esc para terminar: 1. Piernas, 2. Brazos, 3. Abdominales");
return tipo;

}

 function seleccionNivel(){

 
    let nivel= prompt("seleccione su nivel: 1. principiante, 2. intermedio, 3. avanzado");
 return nivel;
 
 }

 function mostrarRutina(opcion,nivel){

    if (opcion==1 ) {

         switch(nivel) {
                case "1":
                    alert( "4x10 sentadillas");
                    break;

                 case "2":
                    alert( "4x20 sentadillas");
                    break;

                case "3":
                    alert( "4x30 sentadillas");
                    break;

                    default:
                        alert("invalid")
                        break


         }


    } else if (opcion==2){

        switch (nivel) {

            case "1":
                alert( "4x10 curl de biceps");
                break;

             case "2":
                alert( "4x20 curl de biceps");
                break;

            case "3":
                alert( "4x30 culr de biceps");
                break;

                default:
                    alert("invalid")
                    break;


     }


    }
    else if (opcion==3){

        switch (nivel) {

            case "1":
                alert( "4x10 abs cortos");
                break;

             case "2":
                alert( "4x20 abs cortos");
                break;

            case "3":
                alert( "4x30 abs cortos");
                break;

                default:
                    alert("invalid")
                    break;


     };


    } else{   
        alert("invalid");
        
    }

 
 }

let opcion="inicio";
while(opcion!="esc") {
 
 opcion = seleccionTipo();

 let nivel = seleccionNivel();

 mostrarRutina(opcion, nivel);

    
}